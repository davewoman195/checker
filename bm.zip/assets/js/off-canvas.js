(function($) {
  'use strict';
  $(function() {
    $('[data-toggle="offcanvas"]').on("hover", function() {
      $('.sidebar-offcanvas').toggleClass('active')
    });
  });
})(jQuery);